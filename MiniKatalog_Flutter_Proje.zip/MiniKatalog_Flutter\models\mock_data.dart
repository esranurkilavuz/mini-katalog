import 'dart:convert';
import 'product.dart';

const String mockJsonData = '''
[
  {
    "id": 1,
    "title": "Fjallraven - No. 1 Sırt Çantası, 15 İnç Uyumlu",
    "price": 109.95,
    "description": "Günlük kullanım ve doğa yürüyüşleri için mükemmel çantanız. Dizüstü bilgisayarınızı (15 inçe kadar) destekli bölmeye, günlük eşyalarınızı geniş ana bölmeye koyabilirsiniz.",
    "category": "erkek giyim",
    "image": "assets/images/1.png"
  },
  {
    "id": 2,
    "title": "Erkek Günlük Premium Dar Kesim T-Shirt",
    "price": 22.3,
    "description": "Dar kesim, hafif ve yumuşak kumaşıyla nefes alabilen ve rahat bir giyim deneyimi sunar.",
    "category": "erkek giyim",
    "image": "assets/images/2.png"
  },
  {
    "id": 3,
    "title": "Erkek Pamuklu Ceket",
    "price": 55.99,
    "description": "İlkbahar, Sonbahar ve Kış için harika bir dış giyim. Çalışma, yürüyüş, kamp veya seyahat gibi pek çok durum için uygundur.",
    "category": "erkek giyim",
    "image": "assets/images/3.png"
  },
  {
    "id": 4,
    "title": "Erkek Günlük Dar Kesim Gömlek",
    "price": 15.99,
    "description": "Renkler ekran ve gerçekte biraz farklılık gösterebilir. Ürün açıklamalarından detaylı beden tablosuna bakabilirsiniz.",
    "category": "erkek giyim",
    "image": "assets/images/4.png"
  },
  {
    "id": 5,
    "title": "Kadın Gümüş & Altın Ejderha Motifli Bileklik",
    "price": 695.0,
    "description": "Efsaneler Koleksiyonumuzdan. Okyanus incisini koruyan efsanevi su ejderhasından ilham alınarak tasarlanmıştır.",
    "category": "takı",
    "image": "assets/images/5.png"
  },
  {
    "id": 6,
    "title": "Saf Altın Zarif İnce Yüzük",
    "price": 168.0,
    "description": "Müşteri memnuniyeti garantilidir. 30 gün içinde iade veya değişim imkanı sunulmaktadır.",
    "category": "takı",
    "image": "assets/images/6.png"
  }
]
''';

List<Product> getMockProducts() {
  final List<dynamic> parsedList = json.decode(mockJsonData);
  return parsedList.map((json) => Product.fromJson(json)).toList();
}

import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(MiniKatalogApp());
}

class MiniKatalogApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mini Katalog',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        scaffoldBackgroundColor: Colors.grey[50],
        fontFamily: 'Roboto',
      ),
      home: HomeScreen(),
    );
  }
}
